import numpy as np

def rmse(arr):
    a = np.asarray(arr, dtype=float)
    return float(np.sqrt(np.mean(a * a))) if a.size else float("nan")

def touchdown(x, h, x_thresh=0.0, h_thresh=15.0):
    """
    Heuristic touchdown/threshold proximity condition.
    x_thresh: runway threshold x position (m)
    h_thresh: flare/near-ground height (m)
    """
    return (x >= x_thresh - 10.0) and (h <= h_thresh + 1.0)

def stabilized_gate(y_err, V_err, gamma, h, gate_h=300.0):
    """
    Simple stabilized approach check below gate_h (meters).
    Returns True if stable, False otherwise.
    """
    if h > gate_h:
        return True
    if abs(y_err) > 80.0:   # meters
        return False
    if abs(V_err) > 7.0:    # m/s
        return False
    if abs(gamma) > np.deg2rad(8.0):
        return False
    return True

def _slice_mask_by_height(h, h_max=None, h_min=None):
    h = np.asarray(h, dtype=float)
    m = np.ones_like(h, dtype=bool)
    if h_max is not None:
        m &= (h <= float(h_max))
    if h_min is not None:
        m &= (h >= float(h_min))
    return m

def _safe_max_abs(arr):
    a = np.asarray(arr, dtype=float)
    return float(np.max(np.abs(a))) if a.size else float("nan")

def compute_metrics(log: dict, config: dict | None = None) -> dict:
    """
    Compute performance metrics from a simulation log.

    Expected log keys (recommended):
      - t: time [s]
      - x: along-track position [m] (threshold typically at x=0)
      - y: cross-track position [m] (localizer lateral deviation proxy)
      - h: altitude [m]
      - y_err: lateral error [m] (if absent, uses y)
      - h_err: glideslope error [m] (if absent, attempts to use (h - h_ref) if provided)
      - V: true airspeed [m/s]
      - V_ref: reference speed [m/s] (optional)
      - gamma: flight-path angle [rad] (optional)
      - vs_mps or vs_fpm: vertical speed (optional)

    config (optional):
      - metrics:
          gate_h_m: 300.0
          final_h_max_m: 300.0
          final_h_min_m: 0.0
          touchdown_x_thresh_m: 0.0
          touchdown_h_thresh_m: 15.0
    """
    cfg = (config or {}).get("metrics", {}) if isinstance(config, dict) else {}

    gate_h = float(cfg.get("gate_h_m", 300.0))
    final_h_max = float(cfg.get("final_h_max_m", 300.0))
    final_h_min = float(cfg.get("final_h_min_m", 0.0))
    td_x_thresh = float(cfg.get("touchdown_x_thresh_m", 0.0))
    td_h_thresh = float(cfg.get("touchdown_h_thresh_m", 15.0))

    # Required-ish series
    t = np.asarray(log.get("t", []), dtype=float)
    x = np.asarray(log.get("x", []), dtype=float)
    y = np.asarray(log.get("y", []), dtype=float)
    h = np.asarray(log.get("h", []), dtype=float)

    # Errors (fallbacks)
    y_err = np.asarray(log.get("y_err", y), dtype=float) if y.size else np.asarray(log.get("y_err", []), dtype=float)
    h_err = np.asarray(log.get("h_err", []), dtype=float)

    # If h_err missing but h_ref exists
    if (not h_err.size) and ("h_ref" in log) and (h.size):
        h_ref = np.asarray(log["h_ref"], dtype=float)
        if h_ref.size == h.size:
            h_err = h - h_ref

    V = np.asarray(log.get("V", []), dtype=float)
    V_ref = np.asarray(log.get("V_ref", []), dtype=float)
    gamma = np.asarray(log.get("gamma", []), dtype=float)

    # Vertical speed
    if "vs_fpm" in log:
        vs_fpm = np.asarray(log["vs_fpm"], dtype=float)
    elif "vs_mps" in log:
        vs_fpm = np.asarray(log["vs_mps"], dtype=float) * 196.850394  # m/s -> fpm
    else:
        vs_fpm = np.asarray([], dtype=float)

    # Speed error if possible
    if V.size and V_ref.size and V_ref.size == V.size:
        V_err = V - V_ref
    else:
        V_err = np.asarray([], dtype=float)

    out = {}

    # Global metrics
    out["RMS_y_err_m"] = rmse(y_err) if y_err.size else float("nan")
    out["MAX_abs_y_err_m"] = _safe_max_abs(y_err) if y_err.size else float("nan")

    if h_err.size:
        out["RMS_h_err_m"] = rmse(h_err)
        out["MAX_abs_h_err_m"] = _safe_max_abs(h_err)
    else:
        out["RMS_h_err_m"] = float("nan")
        out["MAX_abs_h_err_m"] = float("nan")

    if vs_fpm.size:
        out["MAX_abs_vs_fpm"] = _safe_max_abs(vs_fpm)
    else:
        out["MAX_abs_vs_fpm"] = float("nan")

    # Final segment metrics (by altitude band)
    if h.size and (y_err.size == h.size):
        m_final = _slice_mask_by_height(h, h_max=final_h_max, h_min=final_h_min)
        y_final = y_err[m_final]
        out["FINAL_RMS_y_err_m"] = rmse(y_final) if y_final.size else float("nan")
        out["FINAL_MAX_abs_y_err_m"] = _safe_max_abs(y_final) if y_final.size else float("nan")
    else:
        out["FINAL_RMS_y_err_m"] = float("nan")
        out["FINAL_MAX_abs_y_err_m"] = float("nan")

    if h.size and h_err.size and (h_err.size == h.size):
        m_final = _slice_mask_by_height(h, h_max=final_h_max, h_min=final_h_min)
        herr_final = h_err[m_final]
        out["FINAL_RMS_h_err_m"] = rmse(herr_final) if herr_final.size else float("nan")
        out["FINAL_MAX_abs_h_err_m"] = _safe_max_abs(herr_final) if herr_final.size else float("nan")
    else:
        out["FINAL_RMS_h_err_m"] = float("nan")
        out["FINAL_MAX_abs_h_err_m"] = float("nan")

    # Stabilized approach check below gate_h (percentage stable)
    stable_ratio = float("nan")
    if h.size and y_err.size and gamma.size and (y_err.size == h.size == gamma.size):
        # V_err required for your stabilized_gate; if missing, treat as 0 (or skip).
        if not V_err.size:
            V_err_use = np.zeros_like(h)
        else:
            V_err_use = V_err

        m_gate = (h <= gate_h)
        if np.any(m_gate):
            stable_flags = []
            idxs = np.where(m_gate)[0]
            for i in idxs:
                stable_flags.append(
                    stabilized_gate(
                        y_err=float(y_err[i]),
                        V_err=float(V_err_use[i]) if V_err_use.size == h.size else 0.0,
                        gamma=float(gamma[i]),
                        h=float(h[i]),
                        gate_h=gate_h,
                    )
                )
            stable_flags = np.asarray(stable_flags, dtype=bool)
            stable_ratio = float(np.mean(stable_flags)) if stable_flags.size else float("nan")

    out["STABLE_RATIO_below_gate"] = stable_ratio
    out["GATE_H_m"] = gate_h

    # Touchdown detection (first index satisfying touchdown heuristic)
    td_idx = None
    if x.size and h.size and (x.size == h.size):
        for i in range(x.size):
            if touchdown(x=float(x[i]), h=float(h[i]), x_thresh=td_x_thresh, h_thresh=td_h_thresh):
                td_idx = i
                break

    if td_idx is not None:
        out["TOUCHDOWN_detected"] = True
        out["TOUCHDOWN_index"] = int(td_idx)
        out["TOUCHDOWN_t_s"] = float(t[td_idx]) if t.size == x.size else float("nan")
        out["TOUCHDOWN_x_m"] = float(x[td_idx])
        out["TOUCHDOWN_h_m"] = float(h[td_idx])
        out["TOUCHDOWN_y_m"] = float(y[td_idx]) if y.size == x.size else float("nan")
    else:
        out["TOUCHDOWN_detected"] = False
        out["TOUCHDOWN_index"] = -1
        out["TOUCHDOWN_t_s"] = float("nan")
        out["TOUCHDOWN_x_m"] = float("nan")
        out["TOUCHDOWN_h_m"] = float("nan")
        out["TOUCHDOWN_y_m"] = float("nan")

    return out
